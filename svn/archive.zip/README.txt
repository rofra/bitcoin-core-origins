Bitcoin development has moved from SourceForge to github :
  https://github.com/bitcoin/bitcoin/

